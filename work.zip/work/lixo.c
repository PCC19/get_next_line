#define BUFFER_SIZE 10

int		findnl(char *s)
{
	while ((s) && (*s))
	{
		if (*s == 'x')
			return (1);
		s++;
	}
	return (0);
}

int		len(char *s)
{
	int	c;

	c = 0;
	while ((s) && (*s))
	{
		s++;
		c++;
	}
	return (c);
}

char	*concat(char *str_a, char *str_b)
{
	char	*out;
	char	*p;
	char	*a;
	char	*b;

	out = malloc(len(str_a) + len(str_b) + 1);
	p = out;
	a = str_a;
	b = str_b;
	while ((a) && (*a))
	{
		*p = *a;
		p++;
		a++;
	}
	while ((b) && (*b))
	{
		*p = *b;
		p++;
		b++;
	}
	*p = 0;
	free(str_a);
	return (out);
}

void	dosave(char *l, char *s)
{
	while ((l) && (*l) && (*l != 'x'))
		l++;
	if (*l == 'x')
	{
		*l = 0;
		l++;
	}
	while ((l) && (*l))
	{
		*s = *l;
		l++;
		s++;
	}
	return ;
}


void	clear(char *s)
{
	int	x;

	x = 0;
	while (x < BUFFER_SIZE)
	{
		*(s + x) = 0;
		x++;
	}
	return ;
}

int		get_next_line(int fd, char **line)
{
	static char	save[BUFFER_SIZE + 1];
	int			r;
	char		tmp[BUFFER_SIZE + 1];
	char		*buf;

	if ((!line) || BUFFER_SIZE == 0)
		return (-1);
	*line = concat(NULL, save);
	r = 1;
	while ((r) && (!findnl(*line)))
	{
		buf = tmp;
		//r = read(fd, buf, BUFFER_SIZE);
        r = 20;
        buf = "AxBBxCCCx";
		if (r == -1)
		{
			*line = NULL;
			return (r);
		}
		tmp[r] = 0;
		*line = concat(*line, tmp);
	}
	clear(save);
	dosave(*line, save);
	return (r ? 1 : 0);
}

int main()
{
    char **linha = 0;
    int fd = 0;
    int a = -1;

    a = get_next_line(fd, linha);
    printf("a: %d  Linha: %s\n",a,linha);
    printf("--------------");

    a = get_next_line(fd, linha);
    printf("a: %d  Linha: %s\n",a,linha);
    printf("--------------");
    
    a = get_next_line(fd, linha);
    printf("a: %d  Linha: %s\n",a,linha);
    printf("--------------");
}


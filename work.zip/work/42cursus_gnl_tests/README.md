# 42cursus_gnl_tests
Unit tests for get next line, new subject!

## running
specify your get_next_line folder in the `Makefile`

```sh
make # runs all tests
make buf1 # runs test named buf1, see Makefile for all tests
```

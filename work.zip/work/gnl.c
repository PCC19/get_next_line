#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>

extern int errno;

void	*ft_memset(void *b, int c, size_t len)
{
	unsigned char *ptr;

	ptr = (unsigned char *)b;
	while (len--)
		*ptr++ = (unsigned char)c;
	return (b);
}


int ft_len(char *s)
{
    int i;
    i = 0;
    while (s[i] != 0)
    {
        i++;
    }
    return i;
}

int ft_copia_string(char *origem, char *destino, size_t idx)
{
    size_t i;
    
    i = 0;
    while (i < idx)
    {
        destino[i] = origem[i];
        i++;
    }
    destino[i] = 0;
    return 0;
}

char *ft_strjoin(char *s1, char *s2)
{
    char *temp;
    int n1;
    int n2;
    int i;
    int j;

    n1 = ft_len(s1);
    n2 = ft_len(s2);
    temp = malloc(sizeof(char)*(n1+n2+1));
    i = 0;
    j = 0;
    while(s1[i] != 0)
    {
        temp[j] = s1[i];
        i++;
        j++;
    }
    i = 0;
    while(s2[i] != 0)
    {
        temp[j] = s2[i];
        i++;
        j++;
    }
    temp[j] = 0;
    return temp;
}


int ft_checa_armazem(char **armazem, char *line)
{
    int i;
    int sa;
    char *aux;
    char *temp;
    char *arm;

    arm = *armazem;

    sa = ft_len(arm);
    i = 0;
    while(arm[i] != 0)
    {
        printf("i: %d  a[i]: %c\n",i,arm[i]);
        if(arm[i] == '\n')
        {
            // copia string para line
                // copia de 0 a n para line
            ft_copia_string(arm, line, i);
            //printf("Armazem: %s\n",arm);
            //printf("Line: %s\n",line);

            // extrai string
            if (sa > i)
            {
                // copia de n+1 ate fim para novo aux
                temp = *armazem;
                // aloca novo armazem
                aux = malloc(sizeof(char)*(sa - i));
                ft_copia_string(&arm[i+1],aux,sa-i-1);
                // copia aux para novo armazem
                *armazem = aux;
                free(aux);
            }
            return(1);
        }
    i++;
    }
    // se nao tiver /n no armazem
    printf("Nao achou\n");
    return 0;
}

/*
int get_next_line(int fd, char **line)
{
    static char **armazem;

    armazem[0] = 0;
    fd = fd + 1;
    **line = 0;
    printf("%d\n",fd);
    printf("%s\n",line[0]);
    // ve se tem \n no armazem
    // se tiver
        // extrai string ate /n
        // copia esta string para line
        // retorna 1
    // se nao tiver
        // retorna 0
    // while not eof
        // le buffer
        // acrescenta no armazem
        // ve se tem /n no armazem
}
*/

int main()
{
    char *arm;
    char *dest;
    char *buffer = 0;
    char *temp;
    int fd = 0;
    int BUFFER_SIZE = 50; // substituir pela cte depois
    char *lixo = "ab\n012";
    int i = 0;

    dest = malloc(10);
   
    arm = malloc(10);
    for (i=0;i<=6;i++){
        arm[i] = lixo[i];
    }
    //arm = "ab\n012";
    //     012 3456
    //arm = "abc012";
    //     0123456

//    ft_copia_string(arm ,dest, 6);
    printf("arm: %s\n", arm);
    // checa armazem
    // se houver /n:
        // copia linha para outra variavel (que sera retornada)
        // deixa armazem apenas com o que havia apos o /n
    if (ft_checa_armazem(&arm, dest) == 1)
    {
        // retorna dest
        printf("RETORNO Linha: %s\n",dest);
    }
    else
    {
        printf("Lendo arquivo ...\n");
        //open arquivo
        fd = open("arquivo",O_RDONLY);
        buffer = malloc(BUFFER_SIZE);
        while (read(fd, buffer, BUFFER_SIZE) > 0)
        {   
            printf("\nARM: %s\n",arm);
            printf("\nBUFFER: %s\n",buffer);
            // concatena buffer no armazem
            temp = ft_strjoin(arm, buffer); 
            arm = temp;
            printf("\nNOV ARM: %s\n",arm);
            printf("=============\n");
            if (ft_checa_armazem(&arm, dest) == 1)
            {
                // retorna dest
                printf("RETORNO Linha: %s\n",dest);
                printf("\nARM: %s\n",arm);
                free(dest);
                //free(arm);
                free(buffer);
                return 0;
            }
        // limpa buffer
        ft_memset(buffer,0,BUFFER_SIZE);
        }
        free(dest);
        free(buffer);
        free(arm);
        close(fd);
    }

}   

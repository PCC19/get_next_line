# gnl_unit_tests

<img src="https://codamhero.dev/trol/gnlmeme.jpg" height="400"/>

Before running the tester, update the path variable in run_tests.sh. To run, use `sh run_tests.sh`

To test for bonus, run `sh run_tests.sh bonus`

To test in break malloc mode, run `sh run_tests.sh malloc`

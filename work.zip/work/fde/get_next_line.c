/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fde-capu <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/02/27 16:17:57 by fde-capu          #+#    #+#             */
/*   Updated: 2020/05/25 18:26:33 by pcunha           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

void	clear(char *s)
{
	int	x;

	x = 0;
	while (x < BUFFER_SIZE)
	{
		*(s + x) = 0;
		x++;
	}
	return ;
}

int		get_next_line(int fd, char **line)
{
	static char	save[BUFFER_SIZE + 1];
	int			r;
	char		tmp[BUFFER_SIZE + 1];
	char		*buf;

	if ((!line) || BUFFER_SIZE == 0)
		return (-1);
	*line = concat(NULL, save);
	r = 1;
    //debug("INICIO WHILE");
	while ((r) && (!findnl(*line)))
	{
        //debug("r: %d",r);
        //debug("tmp: %s   buf: %s",tmp,buf);
		buf = tmp;
        //debug("tmp: %s   buf: %s",tmp,buf);
		r = read(fd, buf, BUFFER_SIZE);
        //debug("r: %d",r);
        //debug("tmp: %s   buf: %s",tmp,buf);
		if (r == -1)
		{
			*line = NULL;
			return (r);
		}
		tmp[r] = 0;
        //debug("tmp: %s   buf: %s",tmp,buf);
		//debug("line: %s",*line);
        *line = concat(*line, tmp);
        //debug("line + temp: %s",*line);
        //debug("---------");
	}
	clear(save);
    //debug("APOS LEITURA");
    //debug("A linha:  %s      save: %s",*line, save);
	dosave(*line, save);
    //debug("D linha:  %s      save: %s",*line, save);
	return (r ? 1 : 0);
}

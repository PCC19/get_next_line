/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pcunha <pcunha@student.42sp.org.br>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/05/15 13:15:25 by pcunha            #+#    #+#             */
/*   Updated: 2020/05/25 17:35:50 by pcunha           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include "get_next_line.h"

int main()
{
       int fd, fd1, fd2;
        int a;
        int b = 1;
        char *linha;

        linha = "";
        a = 1;
        printf("Lendo arquivo ...\n");
        //open arquivo
        //fd = open("4-five",O_RDONLY);
        fd1 = open("test_file10",O_RDONLY);
        fd = open("arquivo",O_RDONLY);
        fd2 = open("arquivo3",O_RDONLY);
        
        //debug("fds: %d, %d, %d",fd, fd1, fd2);

    /*    a = get_next_line(42, &linha);   
        printf("----------------\n");
        printf("LINHA: %s\n",linha);
        printf("Return: %d\n",a);
        printf("================\n");
*/
        while (b<9)
        {
        a = get_next_line(fd, &linha);
        printf("----------------\n");
        printf("LINHA: %s\n",linha);
        printf("Return: %d\n",a);
        printf("================\n");
        free(linha);
        b++;
        //if (!a)
           // b = 0;
        }
       //free(linha); 
/*        
        a = get_next_line(fd, &linha);   
        printf("----------------\n");
        printf("LINHA: %s\n",linha);
        printf("Return: %d\n",a);
        printf("================\n");
        
        a = get_next_line(fd, &linha);   
        printf("----------------\n");
        printf("LINHA: %s\n",linha);
        printf("Return: %d\n",a);
        printf("================\n");
        
        a = get_next_line(fd1, &linha);   
        printf("----------------\n");
        printf("LINHA: %s\n",linha);
        printf("Return: %d\n",a);
        printf("================\n");
        
        a = get_next_line(fd, &linha);   
        printf("----------------\n");
        printf("LINHA: %s\n",linha);
        printf("Return: %d\n",a);
        printf("================\n");
        
        a = get_next_line(fd2, &linha);   
        printf("----------------\n");
        printf("LINHA: %s\n",linha);
        printf("Return: %d\n",a);
        printf("================\n");
        
        a = get_next_line(fd2, &linha);   
        printf("----------------\n");
        printf("LINHA: %s\n",linha);
        printf("Return: %d\n",a);
        printf("================\n");
        
        a = get_next_line(fd2, &linha);   
        printf("----------------\n");
        printf("LINHA: %s\n",linha);
        printf("Return: %d\n",a);
        printf("================\n");
        
         a = get_next_line(fd2, &linha);   
        printf("----------------\n");
        printf("LINHA: %s\n",linha);
        printf("Return: %d\n",a);
        printf("================\n");
  */      
        close(fd);

/*
aaa|Naa|NaN|a

r 3
aaa

r 3
aaaNaa
retorna aaa 1
sobra aa

r 3
aaNaN
retorna aa 1
sobra aN

r 1
aNa
r 0
aNa
retorna a 1
sobra a

r 0
a
retorna a 0
sobra ""
rd = 0 e armazem vazio

le arquivo ate um /n ou ate final do arquivo
retorna linha ate /n ou final do arquivo
salva apos /n 
se rd = 0 e salvou vazio, retorna 0 senao 1

1       0
aaaaaaN|aaa|
1       1
aaaaaaN|aaN|
1       1 0
aaaaaaN|N|

aaaaaaN|aNa|

aaaaaaN|Naa|

rd == 0
se na linha extraida tinha n: retorna 1

012 3
aaN|a

aaaa|



*/



}


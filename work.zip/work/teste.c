#include <stdio.h>

int funcao(int i)
{
    static int a;

    a = a + 1;
    printf("i: %d\n",i);
    printf("a: %d\n",a);

    return a;
}

int main()
{
    int j;
    int x;
    for(j=0;j<10;j++)
    {
        x = funcao(j);
    }
}

